import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type UserRole = 'fisherman' | 'family'

interface User {
  name: string
  phone: string
  role: UserRole
}

interface AuthState {
  selectedRole: UserRole | null
  user: User | null
  setSelectedRole: (role: UserRole) => void
  login: (user: User) => void
  logout: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      selectedRole: null,
      user: null,

      setSelectedRole: (role) => set({ selectedRole: role }),

      login: (user) => set({ user, selectedRole: user.role }),

      logout: () => set({ user: null }),
    }),
    {
      name: 'matsya-auth',
    }
  )
)