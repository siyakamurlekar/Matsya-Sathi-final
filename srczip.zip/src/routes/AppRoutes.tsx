import { Routes, Route, Navigate, useNavigate } from 'react-router-dom'
import DashboardPage from '../pages/Fisherman/DashboardPage'
import FamilyDashboardPage from '../pages/Family/FamilyDashboardPage'
import { useAuthStore } from '../store/authStore'

import SplashPage from '../pages/Splash/SplashPage'
import LanguagePage from '../pages/Language/LanguagePage'
import RolePage from '../pages/Role/RolePage'
import LoginPage from '../pages/Auth/LoginPage'
import RegisterPage from '../pages/Auth/RegisterPage'

export default function AppRoutes() {
  const navigate = useNavigate()
  const user = useAuthStore((state) => state.user)

  return (
    <Routes>
      <Route
        path="/"
        element={
          <div onClick={() => navigate('/language')}>
            <SplashPage />
          </div>
        }
      />

      <Route
        path="/language"
        element={
          <LanguagePage onContinue={() => navigate('/role')} />
        }
      />

      <Route path="/role" element={<RolePage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      <Route path="*" element={<Navigate to="/" replace />} />
      <Route
  path="/fisherman"
  element={
    user?.role === 'fisherman'
      ? <DashboardPage />
      : <Navigate to="/login" replace />
  }
/>

<Route
  path="/family"
  element={
    user?.role === 'family'
      ? <FamilyDashboardPage />
      : <Navigate to="/login" replace />
  }
/>
    </Routes>
  )
}