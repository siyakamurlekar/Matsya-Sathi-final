import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import styles from '../../styles/Dashboard.module.css'
import { useTranslation } from 'react-i18next'

export default function DashboardPage() {
  const navigate = useNavigate()
  const user = useAuthStore((state) => state.user)
  const logout = useAuthStore((state) => state.logout)
  const { t } = useTranslation()

  return (
    <main className={styles.page}>
      <div className={styles.container}>
        <header className={styles.header}>
          <div>
            <p className={styles.eyebrow}>MATSYA SATHI · FISHERMAN</p>
            <h1>
              Namaskar, {user?.name?.split(' ')[0] || 'Fisherman'}!
            </h1>
            <p className={styles.muted}>
              Your companion for safer days at sea.
            </p>
          </div>

          <button
            className={styles.outlineButton}
            onClick={() => {
              logout()
              navigate('/role', { replace: true })
            }}
          >
            Sign out
          </button>
        </header>

        <section className={styles.hero}>
          <div>
            <span className={styles.badge}>● DEMO SEA BULLETIN</span>
            <h2>Know the sea before you sail.</h2>
            <p>
              Check conditions, prepare your trip, and stay connected
              with your family.
            </p>
            <button
              className={styles.primaryButton}
              onClick={() => navigate('/fisherman/sea')}
            >
              View sea conditions →
            </button>
          </div>
          <div className={styles.heroIcon} aria-hidden="true">
            🌊
          </div>
        </section>

        <section className={styles.section}>
          <div className={styles.sectionHeading}>
            <h2>Your safety overview</h2>
            <span className={styles.muted}>Demo information</span>
          </div>

          <div className={styles.stats}>
            <article className={styles.statCard}>
              <span>🌤️ Weather</span>
              <strong>Partly cloudy</strong>
              <small>Illustrative conditions</small>
            </article>

            <article className={styles.statCard}>
              <span>🌬️ Wind</span>
              <strong>12 km/h</strong>
              <small>Demo reading</small>
            </article>

            <article className={styles.statCard}>
              <span>📡 Beacon</span>
              <strong>Not connected</strong>
              <small>Hardware integration pending</small>
            </article>
          </div>
        </section>

        <section className={styles.section}>
          <div className={styles.sectionHeading}>
            <h2>What would you like to do?</h2>
          </div>

          <div className={styles.actions}>
            <button
              className={styles.actionCard}
              onClick={() => navigate('/fisherman/trip')}
            >
              <span className={styles.actionIcon}>🚤</span>
              <strong>Start a fishing trip</strong>
              <small>Manage your journey and safety status.</small>
              <span className={styles.actionLink}>Open trip →</span>
            </button>

            <button
              className={styles.actionCard}
              onClick={() => navigate('/fisherman/schemes')}
            >
              <span className={styles.actionIcon}>📋</span>
              <strong>{t('schemes')}</strong>
              <small>Discover welfare support you may qualify for.</small>
              <span className={styles.actionLink}>Explore schemes →</span>
            </button>

            <button
              className={styles.actionCard}
              onClick={() => navigate('/fisherman/sea')}
            >
              <span className={styles.actionIcon}>🌊</span>
              <strong>Sea conditions</strong>
              <small>Review wind, waves, and sailing advisories.</small>
              <span className={styles.actionLink}>View bulletin →</span>
            </button>

            <button
              className={`${styles.actionCard} ${styles.sosCard}`}
              onClick={() => navigate('/sos')}
            >
              <span className={styles.actionIcon}>🆘</span>
              <strong>{t('emergencySOS')}</strong>
              <small>Access the emergency alert workflow.</small>
              <span className={styles.actionLink}>Open SOS →</span>
            </button>
          </div>
        </section>

        <nav className={styles.bottomNav} aria-label="Fisherman navigation">
          <button className={styles.activeNav} onClick={() => navigate('/fisherman')}>
            🏠 Home
          </button>
          <button onClick={() => navigate('/fisherman/sea')}>🌊 Sea</button>
          <button onClick={() => navigate('/fisherman/trip')}>🚤 Trip</button>
          <button onClick={() => navigate('/fisherman/schemes')}>📋 Schemes</button>
        </nav>
      </div>
    </main>
  )
}