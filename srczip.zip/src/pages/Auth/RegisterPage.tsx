import { useState, type FormEvent } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import styles from './Auth.module.css'

export default function RegisterPage() {
  const navigate = useNavigate()
  const { selectedRole, login, user } = useAuthStore()

  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [village, setVillage] = useState('')
  const [boatName, setBoatName] = useState('')

  if (user) {
    return <Navigate to={user.role === 'fisherman' ? '/fisherman' : '/family'} replace />
  }

  if (!selectedRole) {
    return <Navigate to="/role" replace />
  }

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()

    if (!name.trim() || !/^[6-9]\d{9}$/.test(phone) || !village.trim()) return

    localStorage.setItem(
      'matsya-profile',
      JSON.stringify({ name, phone, village, boatName, role: selectedRole })
    )

    login({ name: name.trim(), phone, role: selectedRole })

    navigate(selectedRole === 'fisherman' ? '/fisherman' : '/family', {
      replace: true,
    })
  }

  return (
    <main className={styles.page}>
      <section className={styles.card}>
        <div className={styles.brand}>MATSYA SATHI</div>
        <p className={styles.eyebrow}>JOIN OUR COMMUNITY</p>

        <h1>Let's get you started.</h1>
        <p className={styles.description}>
          Create your {selectedRole === 'fisherman' ? 'fisherman' : 'family'} demo profile.
        </p>

        <form onSubmit={handleSubmit} className={styles.form}>
          <label htmlFor="name">Full name</label>
          <input
            id="name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Your full name"
            minLength={2}
            required
          />

          <label htmlFor="phone">Mobile number</label>
          <input
            id="phone"
            type="tel"
            inputMode="numeric"
            maxLength={10}
            value={phone}
            onChange={(event) =>
              setPhone(event.target.value.replace(/\D/g, ''))
            }
            placeholder="10-digit mobile number"
            pattern="[6-9][0-9]{9}"
            required
          />

          <label htmlFor="village">Village / Coastal area</label>
          <input
            id="village"
            value={village}
            onChange={(event) => setVillage(event.target.value)}
            placeholder="e.g. Benaulim, Goa"
            required
          />

          {selectedRole === 'fisherman' && (
            <>
              <label htmlFor="boat">Boat name (optional)</label>
              <input
                id="boat"
                value={boatName}
                onChange={(event) => setBoatName(event.target.value)}
                placeholder="Enter your boat name"
              />
            </>
          )}

          <p className={styles.note}>
            This creates a local demo profile, not a verified online account.
          </p>

          <button type="submit" className={styles.primary}>
            Create Profile →
          </button>
        </form>

        <p className={styles.bottom}>
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </section>
    </main>
  )
}