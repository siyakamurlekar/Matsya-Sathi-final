import { useState, type FormEvent } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import styles from './Auth.module.css'

export default function LoginPage() {
  const navigate = useNavigate()
  const { selectedRole, login, user } = useAuthStore()

  const [phone, setPhone] = useState('')
  const [name, setName] = useState('')

  if (user) {
    return <Navigate to={user.role === 'fisherman' ? '/fisherman' : '/family'} replace />
  }

  if (!selectedRole) {
    return <Navigate to="/role" replace />
  }

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()

    if (!/^[6-9]\d{9}$/.test(phone)) return
    if (!name.trim()) return

    login({
      name: name.trim(),
      phone,
      role: selectedRole,
    })

    navigate(selectedRole === 'fisherman' ? '/fisherman' : '/family', {
      replace: true,
    })
  }

  return (
    <main className={styles.page}>
      <section className={styles.card}>
        <div className={styles.brand}>MATSYA SATHI</div>
        <p className={styles.eyebrow}>WELCOME BACK</p>

        <h1>Welcome aboard.</h1>
        <p className={styles.description}>
          Continue to your {selectedRole === 'fisherman' ? 'fisherman' : 'family'} dashboard.
        </p>

        <form onSubmit={handleSubmit} className={styles.form}>
          <label htmlFor="name">Your name</label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Enter your name"
            required
            minLength={2}
          />

          <label htmlFor="phone">Mobile number</label>
          <input
            id="phone"
            type="tel"
            inputMode="numeric"
            maxLength={10}
            value={phone}
            onChange={(event) =>
              setPhone(event.target.value.replace(/\D/g, ''))
            }
            placeholder="10-digit mobile number"
            pattern="[6-9][0-9]{9}"
            required
          />

          <p className={styles.note}>
            Demo access only. No OTP or real account verification is performed.
          </p>

          <button type="submit" className={styles.primary}>
            Continue to Dashboard →
          </button>
        </form>

        <p className={styles.bottom}>
          New to Matsya Sathi? <Link to="/register">Create account</Link>
        </p>

        <button
          className={styles.textButton}
          onClick={() => navigate('/role')}
          type="button"
        >
          ← Change role
        </button>
      </section>
    </main>
  )
}