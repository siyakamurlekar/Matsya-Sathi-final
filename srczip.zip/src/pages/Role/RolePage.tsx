import { useNavigate } from 'react-router-dom'
import { useAuthStore, type UserRole } from '../../store/authStore'
import styles from './RolePage.module.css'
import { useTranslation } from 'react-i18next'

const roles: {
  id: UserRole
  icon: string
  title: string
  description: string
  features: string[]
}[] = [
  {
    id: 'fisherman',
    icon: '⚓',
    title: "I'm a Fisherman",
    description: 'Your trusted companion before, during, and after every fishing trip.',
    features: ['Sea advisories', 'Safety beacon', 'Welfare schemes'],
  },
  {
    id: 'family',
    icon: '🏠',
    title: "I'm a Family Member",
    description: 'Stay connected with your loved ones while they are out at sea.',
    features: ['Trip monitoring', 'Safety updates', 'Emergency alerts'],
  },
]

export default function RolePage() {
  const navigate = useNavigate()
  const { selectedRole, setSelectedRole } = useAuthStore()
  const { t } = useTranslation()

  return (
    <main className={styles.page}>
      <header className={styles.header}>
        <div className={styles.logo}>MATSYA SATHI</div>
        <span>YOUR COMPANION AT SEA</span>
      </header>

      <section className={styles.content}>
        <p className={styles.step}>STEP 02 / 03</p>

        <h1>How will you use Matsya Sathi?</h1>

        <p className={styles.subtitle}>
          Choose your role to personalize your experience.
        </p>

        <div className={styles.grid}>
          {roles.map((role) => (
            <button
              key={role.id}
              type="button"
              className={`${styles.card} ${
                selectedRole === role.id ? styles.selected : ''
              }`}
              onClick={() => setSelectedRole(role.id)}
              aria-pressed={selectedRole === role.id}
            >
              <span className={styles.icon}>{role.icon}</span>

              <h2>{role.title}</h2>
              <p>{role.description}</p>

              <div className={styles.features}>
                {role.features.map((feature) => (
                  <span key={feature}>✓ {feature}</span>
                ))}
              </div>

              <span className={styles.cardAction}>
                {selectedRole === role.id ? 'Selected ✓' : 'Select role →'}
              </span>
            </button>
          ))}
        </div>

        <div className={styles.actions}>
          <button
            type="button"
            className={styles.back}
            onClick={() => navigate('/language')}
          >
            ← Back
          </button>

          <button
            type="button"
            className={styles.continue}
            disabled={!selectedRole}
            onClick={() => navigate('/login')}
          >
            Continue →
          </button>
        </div>
      </section>
    </main>
  )
}