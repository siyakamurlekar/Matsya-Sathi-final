import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import styles from '../../styles/Dashboard.module.css'

export default function FamilyDashboardPage() {
  const navigate = useNavigate()
  const user = useAuthStore((state) => state.user)
  const logout = useAuthStore((state) => state.logout)

  return (
    <main className={styles.page}>
      <div className={styles.container}>
        <header className={styles.header}>
          <div>
            <p className={styles.eyebrow}>MATSYA SATHI · FAMILY</p>
            <h1>
              Namaskar, {user?.name?.split(' ')[0] || 'Friend'}!
            </h1>
            <p className={styles.muted}>
              Stay close, even when they're out at sea.
            </p>
          </div>

          <button
            className={styles.outlineButton}
            onClick={() => {
              logout()
              navigate('/role', { replace: true })
            }}
          >
            Sign out
          </button>
        </header>

        <section className={styles.hero}>
          <div>
            <span className={styles.badge}>● FAMILY SAFETY CENTER</span>
            <h2>Peace of mind, from shore to sea.</h2>
            <p>
              Follow your loved one's journey and receive
              important trip updates in one place.
            </p>

            <button
              className={styles.primaryButton}
              onClick={() => navigate('/family/tracking')}
            >
              View trip tracking →
            </button>
          </div>

          <div className={styles.heroIcon} aria-hidden="true">
            🛟
          </div>
        </section>

        <section className={styles.section}>
          <div className={styles.sectionHeading}>
            <h2>Connected fishing trip</h2>
            <span className={styles.muted}>Demo trip</span>
          </div>

          <div className={styles.stats}>
            <article className={styles.statCard}>
              <span>🚤 Trip status</span>
              <strong>Not started</strong>
              <small>Waiting for departure</small>
            </article>

            <article className={styles.statCard}>
              <span>📍 Last known location</span>
              <strong>Unavailable</strong>
              <small>Updates appear during a trip</small>
            </article>

            <article className={styles.statCard}>
              <span>📡 Beacon status</span>
              <strong>Offline</strong>
              <small>Demo connectivity</small>
            </article>
          </div>
        </section>

        <section className={styles.section}>
          <div className={styles.sectionHeading}>
            <h2>Your family safety tools</h2>
          </div>

          <div className={styles.actions}>
            <button
              className={styles.actionCard}
              onClick={() => navigate('/family/tracking')}
            >
              <span className={styles.actionIcon}>📍</span>
              <strong>Track fishing trip</strong>
              <small>View location, connectivity, and trip progress.</small>
              <span className={styles.actionLink}>Open tracking →</span>
            </button>

            <button
              className={styles.actionCard}
              onClick={() => navigate('/notifications')}
            >
              <span className={styles.actionIcon}>🔔</span>
              <strong>Safety notifications</strong>
              <small>Review emergency and safe-return updates.</small>
              <span className={styles.actionLink}>View alerts →</span>
            </button>
          </div>
        </section>

        <nav className={styles.bottomNav} aria-label="Family navigation">
          <button className={styles.activeNav} onClick={() => navigate('/family')}>
            🏠 Home
          </button>
          <button onClick={() => navigate('/family/tracking')}>
            📍 Tracking
          </button>
          <button onClick={() => navigate('/notifications')}>
            🔔 Alerts
          </button>
        </nav>
      </div>
    </main>
  )
}