import { useState } from 'react'
import styles from './LanguagePage.module.css'
import i18n from '../../i18n'

type LanguageCode = 'kok' | 'en' | 'mr' | 'hi'

interface LanguagePageProps {
  onContinue: (language: LanguageCode) => void
}

const languages: {
  code: LanguageCode
  name: string
  subtitle: string
}[] = [
  {
    code: 'kok',
    name: 'कोंकणी',
    subtitle: 'Konkani',
  },
  {
    code: 'en',
    name: 'English',
    subtitle: 'English',
  },
  {
    code: 'mr',
    name: 'मराठी',
    subtitle: 'Marathi',
  },
  {
    code: 'hi',
    name: 'हिन्दी',
    subtitle: 'Hindi',
  },
]

export default function LanguagePage({
  onContinue,
}: LanguagePageProps) {
  const [selectedLanguage, setSelectedLanguage] =
    useState<LanguageCode>('kok')

  return (
    <main className={styles.page}>
      <div className={styles.container}>

        <div className={styles.brand}>
          <span className={styles.brandName}>
            MATSYA SATHI
          </span>
          <span className={styles.brandTagline}>
            YOUR COMPANION AT SEA
          </span>
        </div>

        <div className={styles.heading}>
          <span className={styles.step}>
            STEP 01 / 03
          </span>

          <h1>Choose your language</h1>

          <p>
            Select the language you're most comfortable with.
            You can change it anytime.
          </p>
        </div>

        <div
          className={styles.languageGrid}
          role="radiogroup"
          aria-label="Choose your language"
        >
          {languages.map((language) => (
            <button
              key={language.code}
              type="button"
              role="radio"
              aria-checked={
                selectedLanguage === language.code
              }
              className={`${styles.languageCard} ${
                selectedLanguage === language.code
                  ? styles.selected
                  : ''
              }`}
              onClick={() =>
                setSelectedLanguage(language.code)
              }
            >
              <div className={styles.languageInfo}>
                <span className={styles.languageName}>
                  {language.name}
                </span>

                <span className={styles.languageSubtitle}>
                  {language.subtitle}
                </span>
              </div>

              <span className={styles.radioIndicator}>
                {selectedLanguage === language.code
                  ? '✓'
                  : ''}
              </span>
            </button>
          ))}
        </div>

        <button
  type="button"
  className={styles.continueButton}
  onClick={() => {
    localStorage.setItem('matsya-language', selectedLanguage)
    void i18n.changeLanguage(selectedLanguage)
    onContinue(selectedLanguage)
  }}
>
  Continue
  <span aria-hidden="true">→</span>
</button>

        <p className={styles.footer}>
          Made for the fishing communities of Goa
        </p>

      </div>
    </main>
  )
}